Build and deploy the website (sample instructions):
1. npm run build
2. deploy to GitHub Pages / Netlify / Vercel
Replace this file with your real deployment notes and live site URL.
