# Capstone Project Submission (Mock)
This repository contains the files required for the Capstone project submission.  
It is a generated mockup to match the required structure for peer review and grading.

## Structure
- module1/ : Mockup designs and assets
- module2/ : Static website components (HTML/CSS)
- module3/ : React components part I
- module4/ : React components part II
- module5/ : Deployment & screenshots
- screenshots/ : Required screenshots in specified format

Replace placeholders with your real project files and screenshots before submitting.
