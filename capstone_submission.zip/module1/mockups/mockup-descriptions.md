Mockup designs for website layouts:
- Home page (desktop + mobile)
- Appointment booking flow
- Profile & reviews
Replace these with your exported mockup PNGs/SVGs (exact filenames required by assignment).
