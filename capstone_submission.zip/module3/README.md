Convert static pages to dynamic React components.
Includes sample components.