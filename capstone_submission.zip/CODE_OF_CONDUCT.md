# Code of Conduct
Be kind. This is a placeholder file for the Capstone submission repository.
